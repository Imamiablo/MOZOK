from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from mozok.config import get_settings


settings = get_settings()

engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    """FastAPI dependency that gives one DB session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

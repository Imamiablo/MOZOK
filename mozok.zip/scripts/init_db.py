from mozok.db.session import engine, Base
from mozok.db import models  # noqa: F401 - imports models so SQLAlchemy sees them
from mozok.entity_state.models import AgentEntityStateRecord  # noqa: F401
from mozok.goals.models import AgentGoalRecord  # noqa: F401
from mozok.knowledge_relations.models import KnowledgeRelationRecord  # noqa: F401
from mozok.procedural_skills.models import AgentProceduralSkillRecord  # noqa: F401
from mozok.lorebook.models import AgentLorebookKnowledgeRecord, LorebookEntryRecord  # noqa: F401


def main():
    Base.metadata.create_all(bind=engine)
    print("Mozok database tables created.")


if __name__ == "__main__":
    main()
